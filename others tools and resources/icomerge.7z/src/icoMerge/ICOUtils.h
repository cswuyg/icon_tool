#pragma once
class CICOUtils
{
public:
	CICOUtils(void);
	~CICOUtils(void);



	static HICON WINAPI ExtractIconAtSize(TCHAR* filePath, UINT nIconIndex, int sz);

	static bool MergeIcons(TCHAR* filePath, UINT nIconIndex,
						   TCHAR* filePath2, UINT nIconIndex2,
						   TCHAR* destICOPath);

	static bool MergeIcons(HICON icon1, HICON icon2, TCHAR* destICOPath);
	static bool ConvertBitmapToICO(HBITMAP* bmps, int bmpsSz, TCHAR* destPath);
	static bool ReadICO(TCHAR* destPath);
};

