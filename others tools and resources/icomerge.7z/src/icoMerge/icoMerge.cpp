// icoMerge.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "ICOUtils.h"

int _tmain(int argc, _TCHAR* argv[])
{

	TCHAR* icoPath1;
	TCHAR* icoPath2;
	TCHAR* icoDestPath;

	if(argc != 4)
	{
		_tprintf(_T("expected usage: [iconPath1] [iconPath2] [destinationPath]\n"));
		return -1;
	}



	icoPath1 = argv[1];
	icoPath2 = argv[2];
	icoDestPath = argv[3];


	if(!CICOUtils::MergeIcons(icoPath1, 0, icoPath2, 0, icoDestPath))
	{
		_tprintf(_T("Failed to merge icons!\n"));
	}


	return 0;
}

