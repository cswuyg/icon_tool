#include "StdAfx.h"
#include "ICOUtils.h"




// These next two structs represent how the icon information is stored
// in an ICO file.
typedef struct
{
	BYTE	bWidth;               // Width of the image
	BYTE	bHeight;              // Height of the image (times 2)
	BYTE	bColorCount;          // Number of colors in image (0 if >=8bpp)
	BYTE	bReserved;            // Reserved
	WORD	wPlanes;              // Color Planes
	WORD	wBitCount;            // Bits per pixel
	DWORD	dwBytesInRes;         // how many bytes in this resource?
	DWORD	dwImageOffset;        // where in the file is this image
} ICONDIRENTRY, *LPICONDIRENTRY;
typedef struct 
{
	WORD			idReserved;   // Reserved
	WORD			idType;       // resource type (1 for icons)
	WORD			idCount;      // how many images?
	ICONDIRENTRY	idEntries[1]; // the entries for each image
} ICONDIR, *LPICONDIR;

typedef struct
{
	UINT			Width, Height, Colors; // Width, Height and bpp
	LPBYTE			lpBits;                // ptr to DIB bits
	DWORD			dwNumBytes;            // how many bytes?
	LPBITMAPINFO	lpbi;                  // ptr to header
	LPBYTE			lpXOR;                 // ptr to XOR image bits
	LPBYTE			lpAND;                 // ptr to AND image bits
} ICONIMAGE, *LPICONIMAGE;


#pragma pack( push )
#pragma pack( 2 )
typedef struct
{
   BYTE   bWidth;               // Width, in pixels, of the image
   BYTE   bHeight;              // Height, in pixels, of the image
   BYTE   bColorCount;          // Number of colors in image (0 if >=8bpp)
   BYTE   bReserved;            // Reserved
   WORD   wPlanes;              // Color Planes
   WORD   wBitCount;            // Bits per pixel
   DWORD   dwBytesInRes;         // how many bytes in this resource?
   WORD   nID;                  // the ID
} GRPICONDIRENTRY, *LPGRPICONDIRENTRY;
#pragma pack( pop )

#pragma pack( push )
#pragma pack( 2 )
typedef struct 
{
   WORD            idReserved;   // Reserved (must be 0)
   WORD            idType;       // Resource type (1 for icons)
   WORD            idCount;      // How many images?
   GRPICONDIRENTRY   idEntries[1]; // The entries for each image
} GRPICONDIR, *LPGRPICONDIR;
#pragma pack( pop )

// How wide, in bytes, would this many bits be, DWORD aligned?
#define WIDTHBYTES(bits)      ((((bits) + 31)>>5)<<2)


CICOUtils::CICOUtils(void)
{
}


CICOUtils::~CICOUtils(void)
{
}

struct MyEnumData
{
    UINT nIconIndex;
    HICON hIcon;
	int sz;
	int bitCount;
};

BOOL CALLBACK FindGroupIconProc(HANDLE hModule, LPCTSTR lpszType, LPTSTR lpszName, LONG lParam)
{
    MyEnumData *data = (MyEnumData*) lParam;

    if( data->nIconIndex == 0 )
    {
        HRSRC hRsrc = FindResource((HMODULE)hModule, lpszName, lpszType);
        HGLOBAL hGroup = LoadResource((HMODULE)hModule, hRsrc);        

		GRPICONDIR * lpGrpIconDir = (LPGRPICONDIR)LockResource( hGroup ); 
        for( int i=0; i < lpGrpIconDir->idCount; ++i )
        {              
            GRPICONDIRENTRY * e = &lpGrpIconDir->idEntries[i];
            hRsrc = FindResource((HMODULE) hModule, MAKEINTRESOURCE( e->nID ), RT_ICON );
            HGLOBAL hGlobal = LoadResource( (HMODULE)hModule, hRsrc );
            ICONIMAGE *lpIconImage = (LPICONIMAGE)LockResource( hGlobal );

			if(e->bWidth == data->sz && e->wBitCount == data->bitCount)
			{
				data->hIcon = CreateIconFromResourceEx(
												(PBYTE)lpIconImage,
												e->dwBytesInRes,
												TRUE,
												0x00030000,//DWORD dwVersion,
												e->bWidth,
												e->bHeight,
												0 );               
			}
        }; 

	

		return FALSE;
    }

    --(data->nIconIndex);
    return TRUE;
}

HICON WINAPI CICOUtils::ExtractIconAtSize(TCHAR* filePath, UINT nIconIndex, int sz)
{
    HMODULE hLib = LoadLibraryEx(filePath, NULL, LOAD_LIBRARY_AS_DATAFILE);
    if( !hLib )
        return NULL;

    MyEnumData data;
    data.nIconIndex = nIconIndex;
    data.hIcon = NULL;
	data.sz = sz;
	data.bitCount = 32;

    EnumResourceNames(hLib, RT_GROUP_ICON, (ENUMRESNAMEPROC)&FindGroupIconProc, (LONG)&data);

    FreeLibrary(hLib);
    return data.hIcon;
} 

bool CICOUtils::MergeIcons(TCHAR* filePath, UINT nIconIndex,
						   TCHAR* filePath2, UINT nIconIndex2,
						   TCHAR* destICOPath)
{

	if(_tcslen(filePath) < 5)
		return false;
	if(_tcslen(filePath2) < 5)
		return false;
	if(_tcslen(destICOPath) < 5)
		return false;

	//These are the icons sizes that we are looking for
	int targetSizes[] = {16,32,48,128};

	int targetCount = sizeof(targetSizes) / sizeof(int);
	HBITMAP* bmps = (HBITMAP*)malloc(sizeof(HBITMAP)*targetCount);
	if(bmps == NULL)
		return false;

	HDC hdc = NULL;

	int iBmp = 0;
	for(int i=0;i<targetCount;i++)
	{
		int sz = targetSizes[i];

		//get icons
		HICON icon1,icon2;
		
		if( _tcscmp( filePath + (_tcslen(filePath) - 4), _T(".ico")) == 0)
		{
			icon1 = (HICON) LoadImage(NULL,filePath,IMAGE_ICON,sz,sz, LR_LOADFROMFILE);
		}
		else
		{
			icon1 = ExtractIconAtSize(filePath,nIconIndex, sz);
		}

		if( _tcscmp( filePath2 + (_tcslen(filePath2) - 4), _T(".ico")) == 0)
		{
			icon2 = (HICON) LoadImage(NULL,filePath2,IMAGE_ICON,sz,sz, LR_LOADFROMFILE);
		}
		else
		{
			icon2 = ExtractIconAtSize(filePath2,nIconIndex2, sz);
		}

		if(ico1 == NULL || ico2 == NULL)
		{
			continue; //skip
		}

		//create bmp
		bmps[iBmp] = ::CreateBitmap(sz,sz,1,32,NULL);
		hdc = CreateCompatibleDC(NULL);
		SelectObject(hdc, bmps[iBmp]);

		//draw
		DrawIconEx(hdc,0,0,icon1,sz,sz,0,NULL, DI_NORMAL);
		DrawIconEx(hdc,0,0,icon2,sz,sz,0,NULL, DI_NORMAL);

		SelectObject(hdc, (HBITMAP)NULL);
		DeleteObject(hdc);

		DestroyIcon(icon1);
		DestroyIcon(icon2);
		iBmp++;
	}

	bool ret = ConvertBitmapToICO(bmps, iBmp, destICOPath);

	for(int i=0;i<iBmp;i++)
	{
		if(bmps[i] != NULL)
			DeleteObject(bmps[i]);
	}

	free(bmps);

	return ret;
}


ICONIMAGE CreateIconImageFromBitmap(HBITMAP bmp)
{

	BITMAPINFO info;
	ZeroMemory(&info,sizeof(BITMAPINFO));	
	info.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);

	HDC hdc = GetDC(NULL);	
	GetDIBits(hdc, bmp, 0, 0, NULL, &info, DIB_RGB_COLORS);

	DWORD sz = info.bmiHeader.biWidth * info.bmiHeader.biHeight * 4;
	BYTE* pPixels = (BYTE*)malloc(sizeof(BYTE)*sz);
	memset(pPixels, 0, sz);	
		
	info.bmiHeader.biSize = sizeof(info.bmiHeader);
	info.bmiHeader.biBitCount = 32;
	info.bmiHeader.biCompression = BI_RGB;
	info.bmiHeader.biHeight = (info.bmiHeader.biHeight < 0) ? (-info.bmiHeader.biHeight) : (info.bmiHeader.biHeight);  // correct the bottom-up ordering of lines

	GetDIBits(hdc, bmp, 0, info.bmiHeader.biHeight, (LPVOID)pPixels, &info, DIB_RGB_COLORS);	

	LONG width = info.bmiHeader.biWidth;
	LONG height = info.bmiHeader.biHeight;
	
	LONG imgSz = (info.bmiHeader.biWidth*info.bmiHeader.biHeight*(info.bmiHeader.biBitCount/8));
	ICONIMAGE ico;
	ico.Colors = info.bmiHeader.biBitCount;
	ico.Width = width;
	ico.Height = height;

	DWORD xorSz = 0; //ico.Height * BytesPerLine( &info.bmiHeader )
	DWORD andSz = ico.Height * WIDTHBYTES( ico.Width );
	ico.dwNumBytes = sizeof( BITMAPINFOHEADER )
					+ imgSz
					+ xorSz	// XOR mask
                    + andSz; // AND mask

	ico.lpBits = (LPBYTE)malloc(ico.dwNumBytes);
	memset(ico.lpBits, 0, ico.dwNumBytes);

	// Copy the bits
    memcpy(ico.lpBits, &info.bmiHeader, sizeof(BITMAPINFOHEADER));
	memcpy(ico.lpBits + sizeof(BITMAPINFOHEADER), pPixels, imgSz);

    // Adjust internal pointers/variables for new image
    ico.lpbi = (LPBITMAPINFO)(ico.lpBits);    
	ico.lpXOR = ico.lpBits + sizeof(BITMAPINFOHEADER) + imgSz;
    ico.lpAND = ico.lpXOR + xorSz;
	
	if(xorSz > 0)
		memcpy( ico.lpXOR, ico.lpBits + sizeof(BITMAPINFOHEADER), xorSz );

	memset( ico.lpAND, 0x0, andSz );

	//fix bmp header for icon
	ico.lpbi->bmiHeader.biHeight *= 2;   
	
	free(pPixels);

	return ico;
}

bool CICOUtils::ConvertBitmapToICO(HBITMAP* bmps, int bmpsSz, TCHAR* destPath)
{

	int entryCount = bmpsSz;
	
	//create icons from bitmaps
	ICONIMAGE* icons = (ICONIMAGE*)malloc(sizeof(ICONIMAGE) * entryCount);
	memset(icons, 0, sizeof(ICONIMAGE) * entryCount);
	for(int i=0;i<bmpsSz;i++)
	{
		icons[i] = CreateIconImageFromBitmap(bmps[i]);
	}
	
	ICONDIR icoDir;
	icoDir.idReserved = 0;
	icoDir.idType = 1;
	icoDir.idCount = entryCount;

	//header
	FILE* fp = NULL;
	_tfopen_s(&fp, destPath,_T("wb"));
	if(fp == NULL)
		return false;

	fwrite(&icoDir.idReserved, sizeof(WORD), 1, fp);
	fwrite(&icoDir.idType, sizeof(WORD), 1, fp);
	fwrite(&icoDir.idCount, sizeof(WORD), 1, fp);

	long entriesPos = ftell(fp);

	//entries
	int entrySz = 16;
	ICONDIRENTRY* entries = (ICONDIRENTRY*)malloc(sizeof(ICONDIRENTRY) * entryCount);
	memset(entries, 0, sizeof(ICONDIRENTRY) * entryCount);

	for(int i=0;i<entrySz * entryCount;i++)
		fwrite(&entrySz,sizeof(BYTE),1, fp);

	//fseek(fp,entriesPos + entrySz * entryCount,SEEK_SET);
	for(int i=0;i<entryCount;i++)
	{
		//seek to imge offset	
		entries[i].dwImageOffset = ftell(fp);
		entries[i].bWidth = icons[i].Width;
		entries[i].bHeight = icons[i].Height;
		entries[i].bColorCount = (BYTE) icons[i].lpbi->bmiHeader.biClrUsed;
		entries[i].wBitCount = icons[i].Colors;
		entries[i].wPlanes = 1;

		icons[i].lpbi->bmiHeader.biSizeImage = 0;
		//write icon image data		
		fwrite( icons[i].lpBits, icons[i].dwNumBytes, 1, fp);
		//

		entries[i].dwBytesInRes = ftell(fp) - entries[i].dwImageOffset;
		//
	}

	//fix entries
	fseek(fp, entriesPos, SEEK_SET);
	for(int i=0;i<entryCount;i++)
	{
		fwrite(&entries[i].bWidth,sizeof(BYTE), 1, fp);
		fwrite(&entries[i].bHeight,sizeof(BYTE), 1, fp);
		fwrite(&entries[i].bColorCount,sizeof(BYTE), 1, fp);
		fwrite(&entries[i].bReserved,sizeof(BYTE), 1, fp);

		fwrite(&entries[i].wPlanes,sizeof(WORD), 1, fp);
		fwrite(&entries[i].wBitCount,sizeof(WORD), 1, fp);
		fwrite(&entries[i].dwBytesInRes,sizeof(DWORD), 1, fp);
		fwrite(&entries[i].dwImageOffset,sizeof(DWORD), 1, fp);
	}

	fclose(fp);

	free(entries);
	for(int i=0;i<bmpsSz;i++)
	{
		free(icons[i].lpBits);
	}
	free(icons);

	return true;
}


bool CICOUtils::ReadICO(TCHAR* destPath)
{

	FILE* fp = NULL;
	_tfopen_s(&fp, destPath,_T("rb"));
	if(fp == NULL)
		return false;

	ICONDIR icoDir;
	//fread(&icoDir,sizeof(ICONDIR),1,fp);
	fread(&icoDir.idReserved,sizeof(WORD), 1, fp);
	fread(&icoDir.idType,sizeof(WORD), 1, fp);
	fread(&icoDir.idCount,sizeof(WORD), 1, fp);

	fread(&icoDir.idEntries[0].bWidth,sizeof(BYTE), 1, fp);
	fread(&icoDir.idEntries[0].bHeight,sizeof(BYTE), 1, fp);
	fread(&icoDir.idEntries[0].bColorCount,sizeof(BYTE), 1, fp);
	fread(&icoDir.idEntries[0].bReserved,sizeof(BYTE), 1, fp);

	fread(&icoDir.idEntries[0].wPlanes,sizeof(WORD), 1, fp);
	fread(&icoDir.idEntries[0].wBitCount,sizeof(WORD), 1, fp);
	fread(&icoDir.idEntries[0].dwBytesInRes,sizeof(DWORD), 1, fp);
	fread(&icoDir.idEntries[0].dwImageOffset,sizeof(DWORD), 1, fp);


	fseek(fp, icoDir.idEntries[0].dwImageOffset, SEEK_SET);

	ICONIMAGE ico;
	ico.lpBits = (LPBYTE)malloc(icoDir.idEntries[0].dwBytesInRes);
	fread(ico.lpBits, icoDir.idEntries[0].dwBytesInRes, 1, fp);

	ico.lpbi = (LPBITMAPINFO) ico.lpBits;

	fclose(fp);

	return true;
}

bool CICOUtils::MergeIcons(HICON icon1, HICON icon2, TCHAR* destICOPath)
{

	int targetSizes[] = {16,32,48,128,256};
	int targetCount = sizeof(targetSizes) / sizeof(int);
	HBITMAP* bmps = (HBITMAP*)malloc(sizeof(HBITMAP)*targetCount);
	if(bmps == NULL)
		return false;

	HDC hdc = NULL;

	for(int i=0;i<targetCount;i++)
	{
		int sz = targetSizes[i];

		//create bmp
		bmps[i] = ::CreateBitmap(sz,sz,1,32,NULL);
		hdc = CreateCompatibleDC(NULL);
		SelectObject(hdc, bmps[i]);

		//draw
		DrawIconEx(hdc,0,0,icon1,sz,sz,0,NULL, DI_NORMAL);
		DrawIconEx(hdc,0,0,icon2,sz,sz,0,NULL, DI_NORMAL);

		SelectObject(hdc, (HBITMAP)NULL);
		DeleteObject(hdc);
	}

	bool ret = false;
	ret = ConvertBitmapToICO(bmps,targetCount, destICOPath);

	for(int i=0;i<targetCount;i++)	
		DeleteObject(bmps[i]);	

	return ret;
}